/*
 * LCD16x2_cfg.c
 *
 *  Created on: Jun 23, 2020
 *      Author: Khaled Magdy
 */

#include "LCD16x2.h"

const LCD16x2_CfgType LCD16x2_CfgParam =
{
	GPIOB,
	GPIO_PIN_12,
	GPIO_PIN_13,
	GPIO_PIN_14,
	GPIO_PIN_15,
	GPIO_PIN_3,
	GPIO_PIN_4,
	50
};
